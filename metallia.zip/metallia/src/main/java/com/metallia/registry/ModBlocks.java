package com.metallia.registry;

import com.metallia.Metallia;
import com.metallia.block.AlloyFurnaceBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, Metallia.MOD_ID);

    // Minerais
    public static final RegistryObject<Block> TIN_ORE = BLOCKS.register("tin_ore",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.IRON_ORE).strength(3.0f, 3.0f)));

    public static final RegistryObject<Block> IGNATIUM_ORE = BLOCKS.register("ignatium_ore",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.NETHER_GOLD_ORE)
                    .strength(4.0f, 4.0f).requiresCorrectToolForDrops()));

    public static final RegistryObject<Block> VOIDIUM_ORE = BLOCKS.register("voidium_ore",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.END_STONE)
                    .strength(5.0f, 6.0f).requiresCorrectToolForDrops()));

    // Blocs de metal
    public static final RegistryObject<Block> TIN_BLOCK = BLOCKS.register("tin_block",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK).strength(4.0f, 6.0f)));

    public static final RegistryObject<Block> BRONZE_BLOCK = BLOCKS.register("bronze_block",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK).strength(5.0f, 6.0f)));

    public static final RegistryObject<Block> IGNATIUM_BLOCK = BLOCKS.register("ignatium_block",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK).strength(6.0f, 8.0f)));

    public static final RegistryObject<Block> VOIDIUM_BLOCK = BLOCKS.register("voidium_block",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.DIAMOND_BLOCK).strength(8.0f, 10.0f)));

    // Fourneau a alliages
    public static final RegistryObject<Block> ALLOY_FURNACE = BLOCKS.register("alloy_furnace",
            () -> new AlloyFurnaceBlock(BlockBehaviour.Properties.copy(Blocks.FURNACE)
                    .lightLevel(state -> state.getValue(AlloyFurnaceBlock.LIT) ? 13 : 0)));

    private ModBlocks() {
    }
}
