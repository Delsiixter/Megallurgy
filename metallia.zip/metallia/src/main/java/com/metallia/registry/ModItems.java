package com.metallia.registry;

import com.metallia.Metallia;
import com.metallia.material.ModArmorMaterials;
import com.metallia.material.ModTiers;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, Metallia.MOD_ID);

    // ---------------------------------------------------------------- Lingots
    public static final RegistryObject<Item> TIN_INGOT = ITEMS.register("tin_ingot",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> BRONZE_INGOT = ITEMS.register("bronze_ingot",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> IGNATIUM_INGOT = ITEMS.register("ignatium_ingot",
            () -> new Item(new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> VOIDIUM_INGOT = ITEMS.register("voidium_ingot",
            () -> new Item(new Item.Properties().fireResistant()));

    // ------------------------------------------------------- Metaux bruts
    public static final RegistryObject<Item> RAW_TIN = ITEMS.register("raw_tin",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> RAW_IGNATIUM = ITEMS.register("raw_ignatium",
            () -> new Item(new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> RAW_VOIDIUM = ITEMS.register("raw_voidium",
            () -> new Item(new Item.Properties().fireResistant()));

    // ---------------------------------------------------- Objets de blocs
    public static final RegistryObject<Item> TIN_ORE = blockItem("tin_ore", ModBlocks.TIN_ORE, false);
    public static final RegistryObject<Item> IGNATIUM_ORE = blockItem("ignatium_ore", ModBlocks.IGNATIUM_ORE, true);
    public static final RegistryObject<Item> VOIDIUM_ORE = blockItem("voidium_ore", ModBlocks.VOIDIUM_ORE, true);
    public static final RegistryObject<Item> TIN_BLOCK = blockItem("tin_block", ModBlocks.TIN_BLOCK, false);
    public static final RegistryObject<Item> BRONZE_BLOCK = blockItem("bronze_block", ModBlocks.BRONZE_BLOCK, false);
    public static final RegistryObject<Item> IGNATIUM_BLOCK = blockItem("ignatium_block", ModBlocks.IGNATIUM_BLOCK, true);
    public static final RegistryObject<Item> VOIDIUM_BLOCK = blockItem("voidium_block", ModBlocks.VOIDIUM_BLOCK, true);
    public static final RegistryObject<Item> ALLOY_FURNACE = blockItem("alloy_furnace", ModBlocks.ALLOY_FURNACE, false);

    // ------------------------------------------------- Outils et armures
    static {
        registerGear("tin", () -> ModTiers.TIN, () -> ModArmorMaterials.TIN, -1, -2.0f, false);
        registerGear("bronze", () -> ModTiers.BRONZE, () -> ModArmorMaterials.BRONZE, -2, -1.0f, false);
        registerGear("ignatium", () -> ModTiers.IGNATIUM, () -> ModArmorMaterials.IGNATIUM, -3, 0.0f, true);
        registerGear("voidium", () -> ModTiers.VOIDIUM, () -> ModArmorMaterials.VOIDIUM, -4, 0.0f, true);
    }

    private static RegistryObject<Item> blockItem(String name, RegistryObject<Block> block, boolean fireResistant) {
        return ITEMS.register(name, () -> new BlockItem(block.get(),
                fireResistant ? new Item.Properties().fireResistant() : new Item.Properties()));
    }

    private static Item.Properties props(boolean fireResistant) {
        return fireResistant ? new Item.Properties().fireResistant() : new Item.Properties();
    }

    private static void registerGear(String metal, Supplier<Tier> tier, Supplier<ArmorMaterial> armor,
                                     int hoeDamage, float hoeSpeed, boolean fireResistant) {
        ITEMS.register(metal + "_sword",
                () -> new SwordItem(tier.get(), 3, -2.4f, props(fireResistant)));
        ITEMS.register(metal + "_pickaxe",
                () -> new PickaxeItem(tier.get(), 1, -2.8f, props(fireResistant)));
        ITEMS.register(metal + "_axe",
                () -> new AxeItem(tier.get(), 6.0f, -3.1f, props(fireResistant)));
        ITEMS.register(metal + "_shovel",
                () -> new ShovelItem(tier.get(), 1.5f, -3.0f, props(fireResistant)));
        ITEMS.register(metal + "_hoe",
                () -> new HoeItem(tier.get(), hoeDamage, hoeSpeed, props(fireResistant)));

        ITEMS.register(metal + "_helmet",
                () -> new ArmorItem(armor.get(), ArmorItem.Type.HELMET, props(fireResistant)));
        ITEMS.register(metal + "_chestplate",
                () -> new ArmorItem(armor.get(), ArmorItem.Type.CHESTPLATE, props(fireResistant)));
        ITEMS.register(metal + "_leggings",
                () -> new ArmorItem(armor.get(), ArmorItem.Type.LEGGINGS, props(fireResistant)));
        ITEMS.register(metal + "_boots",
                () -> new ArmorItem(armor.get(), ArmorItem.Type.BOOTS, props(fireResistant)));
    }

    private ModItems() {
    }
}
