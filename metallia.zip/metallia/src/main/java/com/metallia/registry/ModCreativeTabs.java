package com.metallia.registry;

import com.metallia.Metallia;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, Metallia.MOD_ID);

    public static final RegistryObject<CreativeModeTab> METALLIA_TAB = TABS.register("metallia_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + Metallia.MOD_ID))
                    .icon(() -> new ItemStack(ModItems.BRONZE_INGOT.get()))
                    .displayItems((parameters, output) ->
                            ModItems.ITEMS.getEntries().forEach(item -> output.accept(item.get())))
                    .build());

    private ModCreativeTabs() {
    }
}
