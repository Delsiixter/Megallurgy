package com.metallia.registry;

import com.metallia.Metallia;
import com.metallia.menu.AlloyFurnaceMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModMenuTypes {
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(ForgeRegistries.MENU_TYPES, Metallia.MOD_ID);

    public static final RegistryObject<MenuType<AlloyFurnaceMenu>> ALLOY_FURNACE_MENU =
            MENUS.register("alloy_furnace_menu",
                    () -> IForgeMenuType.create(AlloyFurnaceMenu::new));

    private ModMenuTypes() {
    }
}
