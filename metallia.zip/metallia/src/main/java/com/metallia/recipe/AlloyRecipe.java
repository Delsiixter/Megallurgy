package com.metallia.recipe;

import com.google.gson.JsonObject;
import com.metallia.Metallia;
import com.metallia.registry.ModRecipes;
import net.minecraft.core.NonNullList;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.ShapedRecipe;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

/**
 * Recette du fourneau a alliages : deux ingredients (avec quantites) donnent un resultat.
 * Les deux ingredients peuvent etre places dans n'importe quel ordre.
 */
public class AlloyRecipe implements Recipe<SimpleContainer> {
    private final ResourceLocation id;
    private final Ingredient ingredientA;
    private final int countA;
    private final Ingredient ingredientB;
    private final int countB;
    private final ItemStack result;
    private final int time;

    public AlloyRecipe(ResourceLocation id, Ingredient ingredientA, int countA,
                       Ingredient ingredientB, int countB, ItemStack result, int time) {
        this.id = id;
        this.ingredientA = ingredientA;
        this.countA = countA;
        this.ingredientB = ingredientB;
        this.countB = countB;
        this.result = result;
        this.time = time;
    }

    public int getCountA() {
        return countA;
    }

    public int getCountB() {
        return countB;
    }

    public int getTime() {
        return time;
    }

    /** Vrai si 'first' correspond a l'ingredient A et 'second' a l'ingredient B, avec assez d'objets. */
    public boolean fits(ItemStack first, ItemStack second) {
        return ingredientA.test(first) && first.getCount() >= countA
                && ingredientB.test(second) && second.getCount() >= countB;
    }

    @Override
    public boolean matches(SimpleContainer container, Level level) {
        ItemStack first = container.getItem(0);
        ItemStack second = container.getItem(1);
        return fits(first, second) || fits(second, first);
    }

    @Override
    public ItemStack assemble(SimpleContainer container, RegistryAccess registryAccess) {
        return result.copy();
    }

    @Override
    public boolean canCraftInDimensions(int width, int height) {
        return true;
    }

    @Override
    public ItemStack getResultItem(RegistryAccess registryAccess) {
        return result.copy();
    }

    @Override
    public NonNullList<Ingredient> getIngredients() {
        NonNullList<Ingredient> list = NonNullList.create();
        list.add(ingredientA);
        list.add(ingredientB);
        return list;
    }

    @Override
    public ResourceLocation getId() {
        return id;
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return Serializer.INSTANCE;
    }

    @Override
    public RecipeType<?> getType() {
        return Type.INSTANCE;
    }

    public static class Type implements RecipeType<AlloyRecipe> {
        public static final Type INSTANCE = new Type();
        public static final String ID = "alloying";

        private Type() {
        }

        @Override
        public String toString() {
            return Metallia.MOD_ID + ":" + ID;
        }
    }

    public static class Serializer implements RecipeSerializer<AlloyRecipe> {
        public static final Serializer INSTANCE = new Serializer();

        @Override
        public AlloyRecipe fromJson(ResourceLocation id, JsonObject json) {
            Ingredient a = Ingredient.fromJson(GsonHelper.getAsJsonObject(json, "ingredient_a"));
            int countA = GsonHelper.getAsInt(json, "count_a", 1);
            Ingredient b = Ingredient.fromJson(GsonHelper.getAsJsonObject(json, "ingredient_b"));
            int countB = GsonHelper.getAsInt(json, "count_b", 1);
            ItemStack result = ShapedRecipe.itemStackFromJson(GsonHelper.getAsJsonObject(json, "result"));
            int time = GsonHelper.getAsInt(json, "time", 200);
            return new AlloyRecipe(id, a, countA, b, countB, result, time);
        }

        @Override
        public @Nullable AlloyRecipe fromNetwork(ResourceLocation id, FriendlyByteBuf buf) {
            Ingredient a = Ingredient.fromNetwork(buf);
            int countA = buf.readVarInt();
            Ingredient b = Ingredient.fromNetwork(buf);
            int countB = buf.readVarInt();
            ItemStack result = buf.readItem();
            int time = buf.readVarInt();
            return new AlloyRecipe(id, a, countA, b, countB, result, time);
        }

        @Override
        public void toNetwork(FriendlyByteBuf buf, AlloyRecipe recipe) {
            recipe.ingredientA.toNetwork(buf);
            buf.writeVarInt(recipe.countA);
            recipe.ingredientB.toNetwork(buf);
            buf.writeVarInt(recipe.countB);
            buf.writeItem(recipe.result);
            buf.writeVarInt(recipe.time);
        }
    }
}
