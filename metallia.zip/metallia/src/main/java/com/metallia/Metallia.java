package com.metallia;

import com.metallia.registry.ModBlockEntities;
import com.metallia.registry.ModBlocks;
import com.metallia.registry.ModCreativeTabs;
import com.metallia.registry.ModItems;
import com.metallia.registry.ModMenuTypes;
import com.metallia.registry.ModRecipes;
import com.mojang.logging.LogUtils;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(Metallia.MOD_ID)
public class Metallia {
    public static final String MOD_ID = "metallia";
    public static final Logger LOGGER = LogUtils.getLogger();

    public Metallia() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModBlocks.BLOCKS.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modEventBus);
        ModMenuTypes.MENUS.register(modEventBus);
        ModRecipes.SERIALIZERS.register(modEventBus);
        ModRecipes.TYPES.register(modEventBus);
        ModCreativeTabs.TABS.register(modEventBus);
    }
}
