package com.metallia.block.entity;

import com.metallia.block.AlloyFurnaceBlock;
import com.metallia.menu.AlloyFurnaceMenu;
import com.metallia.recipe.AlloyRecipe;
import com.metallia.registry.ModBlockEntities;
import com.metallia.registry.ModRecipes;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Containers;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class AlloyFurnaceBlockEntity extends BlockEntity implements MenuProvider {
    public static final int SLOT_A = 0;
    public static final int SLOT_B = 1;
    public static final int SLOT_FUEL = 2;
    public static final int SLOT_OUTPUT = 3;
    public static final int SLOT_COUNT = 4;

    private static final int DEFAULT_TIME = 200;

    private final ItemStackHandler itemHandler = new ItemStackHandler(SLOT_COUNT) {
        @Override
        protected void onContentsChanged(int slot) {
            setChanged();
        }

        @Override
        public boolean isItemValid(int slot, @NotNull ItemStack stack) {
            if (slot == SLOT_OUTPUT) {
                return false;
            }
            if (slot == SLOT_FUEL) {
                return ForgeHooks.getBurnTime(stack, null) > 0;
            }
            return true;
        }
    };

    private LazyOptional<IItemHandler> lazyItemHandler = LazyOptional.empty();

    private int progress = 0;
    private int maxProgress = DEFAULT_TIME;
    private int burnTime = 0;
    private int burnTimeTotal = 0;

    protected final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return switch (index) {
                case 0 -> progress;
                case 1 -> maxProgress;
                case 2 -> burnTime;
                case 3 -> burnTimeTotal;
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
            switch (index) {
                case 0 -> progress = value;
                case 1 -> maxProgress = value;
                case 2 -> burnTime = value;
                case 3 -> burnTimeTotal = value;
                default -> {
                }
            }
        }

        @Override
        public int getCount() {
            return 4;
        }
    };

    public AlloyFurnaceBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.ALLOY_FURNACE.get(), pos, state);
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("block.metallia.alloy_furnace");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory inventory, Player player) {
        return new AlloyFurnaceMenu(containerId, inventory, this, this.data);
    }

    @Override
    public <T> @NotNull LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        if (cap == ForgeCapabilities.ITEM_HANDLER) {
            return lazyItemHandler.cast();
        }
        return super.getCapability(cap, side);
    }

    @Override
    public void onLoad() {
        super.onLoad();
        lazyItemHandler = LazyOptional.of(() -> itemHandler);
    }

    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        lazyItemHandler.invalidate();
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        tag.put("inventory", itemHandler.serializeNBT());
        tag.putInt("progress", progress);
        tag.putInt("maxProgress", maxProgress);
        tag.putInt("burnTime", burnTime);
        tag.putInt("burnTimeTotal", burnTimeTotal);
        super.saveAdditional(tag);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        itemHandler.deserializeNBT(tag.getCompound("inventory"));
        progress = tag.getInt("progress");
        maxProgress = tag.contains("maxProgress") ? tag.getInt("maxProgress") : DEFAULT_TIME;
        burnTime = tag.getInt("burnTime");
        burnTimeTotal = tag.getInt("burnTimeTotal");
    }

    public void dropContents() {
        if (level == null) {
            return;
        }
        SimpleContainer container = new SimpleContainer(itemHandler.getSlots());
        for (int i = 0; i < itemHandler.getSlots(); i++) {
            container.setItem(i, itemHandler.getStackInSlot(i));
        }
        Containers.dropContents(level, worldPosition, container);
    }

    private boolean isLit() {
        return burnTime > 0;
    }

    private Optional<AlloyRecipe> getCurrentRecipe() {
        if (level == null) {
            return Optional.empty();
        }
        SimpleContainer container = new SimpleContainer(2);
        container.setItem(0, itemHandler.getStackInSlot(SLOT_A));
        container.setItem(1, itemHandler.getStackInSlot(SLOT_B));
        return level.getRecipeManager().getRecipeFor(ModRecipes.ALLOY_TYPE.get(), container, level);
    }

    private boolean canOutput(AlloyRecipe recipe) {
        ItemStack result = recipe.getResultItem(level.registryAccess());
        ItemStack output = itemHandler.getStackInSlot(SLOT_OUTPUT);
        if (output.isEmpty()) {
            return true;
        }
        return ItemStack.isSameItemSameTags(output, result)
                && output.getCount() + result.getCount() <= output.getMaxStackSize();
    }

    private void craft(AlloyRecipe recipe) {
        ItemStack first = itemHandler.getStackInSlot(SLOT_A);
        ItemStack second = itemHandler.getStackInSlot(SLOT_B);
        boolean direct = recipe.fits(first, second);

        itemHandler.extractItem(SLOT_A, direct ? recipe.getCountA() : recipe.getCountB(), false);
        itemHandler.extractItem(SLOT_B, direct ? recipe.getCountB() : recipe.getCountA(), false);

        ItemStack result = recipe.getResultItem(level.registryAccess());
        ItemStack output = itemHandler.getStackInSlot(SLOT_OUTPUT);
        if (output.isEmpty()) {
            itemHandler.setStackInSlot(SLOT_OUTPUT, result.copy());
        } else {
            ItemStack grown = output.copy();
            grown.grow(result.getCount());
            itemHandler.setStackInSlot(SLOT_OUTPUT, grown);
        }
    }

    public static void tick(Level level, BlockPos pos, BlockState state, AlloyFurnaceBlockEntity entity) {
        boolean wasLit = entity.isLit();
        boolean changed = false;

        if (entity.burnTime > 0) {
            entity.burnTime--;
        }

        Optional<AlloyRecipe> recipe = entity.getCurrentRecipe();
        if (recipe.isPresent() && entity.canOutput(recipe.get())) {
            entity.maxProgress = recipe.get().getTime();

            if (!entity.isLit()) {
                ItemStack fuel = entity.itemHandler.getStackInSlot(SLOT_FUEL);
                if (!fuel.isEmpty()) {
                    int burn = ForgeHooks.getBurnTime(fuel, null);
                    if (burn > 0) {
                        entity.burnTime = burn;
                        entity.burnTimeTotal = burn;
                        if (fuel.hasCraftingRemainingItem()) {
                            entity.itemHandler.setStackInSlot(SLOT_FUEL, fuel.getCraftingRemainingItem());
                        } else {
                            fuel.shrink(1);
                        }
                        changed = true;
                    }
                }
            }

            if (entity.isLit()) {
                entity.progress++;
                changed = true;
                if (entity.progress >= entity.maxProgress) {
                    entity.craft(recipe.get());
                    entity.progress = 0;
                }
            } else if (entity.progress > 0) {
                entity.progress = 0;
                changed = true;
            }
        } else if (entity.progress > 0) {
            entity.progress = 0;
            changed = true;
        }

        if (wasLit != entity.isLit()) {
            state = state.setValue(AlloyFurnaceBlock.LIT, entity.isLit());
            level.setBlock(pos, state, 3);
            changed = true;
        }

        if (changed) {
            setChanged(level, pos, state);
        }
    }
}
