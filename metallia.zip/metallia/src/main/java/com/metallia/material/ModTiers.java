package com.metallia.material;

import com.metallia.Metallia;
import com.metallia.registry.ModItems;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.common.ForgeTier;
import net.minecraftforge.common.TierSortingRegistry;

import java.util.List;

/**
 * Niveaux d'outils des metaux de Metallia.
 * Ordre : pierre < etain < fer < bronze < diamant < ignatium < netherite < voidium
 */
public class ModTiers {
    public static final TagKey<Block> NEEDS_VOIDIUM_TOOL =
            BlockTags.create(new ResourceLocation(Metallia.MOD_ID, "needs_voidium_tool"));

    public static final Tier TIN = TierSortingRegistry.registerTier(
            new ForgeTier(1, 150, 5.5f, 1.5f, 14, BlockTags.NEEDS_STONE_TOOL,
                    () -> Ingredient.of(ModItems.TIN_INGOT.get())),
            new ResourceLocation(Metallia.MOD_ID, "tin"),
            List.of(Tiers.STONE), List.of(Tiers.IRON));

    public static final Tier BRONZE = TierSortingRegistry.registerTier(
            new ForgeTier(2, 320, 6.5f, 2.0f, 10, BlockTags.NEEDS_IRON_TOOL,
                    () -> Ingredient.of(ModItems.BRONZE_INGOT.get())),
            new ResourceLocation(Metallia.MOD_ID, "bronze"),
            List.of(Tiers.IRON), List.of(Tiers.DIAMOND));

    public static final Tier IGNATIUM = TierSortingRegistry.registerTier(
            new ForgeTier(3, 1800, 8.5f, 3.5f, 13, BlockTags.NEEDS_DIAMOND_TOOL,
                    () -> Ingredient.of(ModItems.IGNATIUM_INGOT.get())),
            new ResourceLocation(Metallia.MOD_ID, "ignatium"),
            List.of(Tiers.DIAMOND), List.of(Tiers.NETHERITE));

    public static final Tier VOIDIUM = TierSortingRegistry.registerTier(
            new ForgeTier(4, 2800, 9.5f, 4.5f, 18, NEEDS_VOIDIUM_TOOL,
                    () -> Ingredient.of(ModItems.VOIDIUM_INGOT.get())),
            new ResourceLocation(Metallia.MOD_ID, "voidium"),
            List.of(Tiers.NETHERITE), List.of());

    private ModTiers() {
    }
}
