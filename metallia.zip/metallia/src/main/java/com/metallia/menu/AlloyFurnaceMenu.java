package com.metallia.menu;

import com.metallia.block.entity.AlloyFurnaceBlockEntity;
import com.metallia.registry.ModBlocks;
import com.metallia.registry.ModMenuTypes;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.items.SlotItemHandler;

public class AlloyFurnaceMenu extends AbstractContainerMenu {
    private static final int VANILLA_SLOT_COUNT = 36;
    private static final int TE_FIRST_SLOT_INDEX = VANILLA_SLOT_COUNT;
    private static final int TE_SLOT_COUNT = AlloyFurnaceBlockEntity.SLOT_COUNT;

    public final AlloyFurnaceBlockEntity blockEntity;
    private final Level level;
    private final ContainerData data;

    public AlloyFurnaceMenu(int containerId, Inventory inventory, FriendlyByteBuf extraData) {
        this(containerId, inventory,
                inventory.player.level().getBlockEntity(extraData.readBlockPos()),
                new SimpleContainerData(4));
    }

    public AlloyFurnaceMenu(int containerId, Inventory inventory, BlockEntity entity, ContainerData data) {
        super(ModMenuTypes.ALLOY_FURNACE_MENU.get(), containerId);
        this.blockEntity = (AlloyFurnaceBlockEntity) entity;
        this.level = inventory.player.level();
        this.data = data;

        addPlayerInventory(inventory);
        addPlayerHotbar(inventory);

        this.blockEntity.getCapability(ForgeCapabilities.ITEM_HANDLER).ifPresent(handler -> {
            this.addSlot(new SlotItemHandler(handler, AlloyFurnaceBlockEntity.SLOT_A, 38, 17));
            this.addSlot(new SlotItemHandler(handler, AlloyFurnaceBlockEntity.SLOT_B, 74, 17));
            this.addSlot(new SlotItemHandler(handler, AlloyFurnaceBlockEntity.SLOT_FUEL, 56, 53));
            this.addSlot(new SlotItemHandler(handler, AlloyFurnaceBlockEntity.SLOT_OUTPUT, 116, 35));
        });

        addDataSlots(data);
    }

    public boolean isCrafting() {
        return data.get(0) > 0;
    }

    public boolean isLit() {
        return data.get(2) > 0;
    }

    /** Largeur de la fleche de progression (0 a 24 pixels). */
    public int getScaledProgress() {
        int progress = data.get(0);
        int maxProgress = data.get(1);
        return maxProgress != 0 && progress != 0 ? progress * 24 / maxProgress : 0;
    }

    /** Hauteur de la flamme restante (0 a 13 pixels). */
    public int getScaledFuel() {
        int total = data.get(3);
        if (total == 0) {
            total = 200;
        }
        return data.get(2) * 13 / total;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        Slot sourceSlot = this.slots.get(index);
        if (sourceSlot == null || !sourceSlot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack sourceStack = sourceSlot.getItem();
        ItemStack copy = sourceStack.copy();

        if (index < VANILLA_SLOT_COUNT) {
            // de l'inventaire du joueur vers le fourneau
            if (!moveItemStackTo(sourceStack, TE_FIRST_SLOT_INDEX, TE_FIRST_SLOT_INDEX + TE_SLOT_COUNT, false)) {
                return ItemStack.EMPTY;
            }
        } else if (index < TE_FIRST_SLOT_INDEX + TE_SLOT_COUNT) {
            // du fourneau vers l'inventaire du joueur
            if (!moveItemStackTo(sourceStack, 0, VANILLA_SLOT_COUNT, false)) {
                return ItemStack.EMPTY;
            }
        } else {
            return ItemStack.EMPTY;
        }

        if (sourceStack.getCount() == 0) {
            sourceSlot.set(ItemStack.EMPTY);
        } else {
            sourceSlot.setChanged();
        }
        sourceSlot.onTake(player, sourceStack);
        return copy;
    }

    @Override
    public boolean stillValid(Player player) {
        return stillValid(ContainerLevelAccess.create(level, blockEntity.getBlockPos()),
                player, ModBlocks.ALLOY_FURNACE.get());
    }

    private void addPlayerInventory(Inventory inventory) {
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(inventory, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
            }
        }
    }

    private void addPlayerHotbar(Inventory inventory) {
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(inventory, col, 8 + col * 18, 142));
        }
    }
}
